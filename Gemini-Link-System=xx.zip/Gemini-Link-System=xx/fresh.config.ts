import { defineConfig } from "$fresh/server.ts";

export default defineConfig({
  plugins: [],
});
